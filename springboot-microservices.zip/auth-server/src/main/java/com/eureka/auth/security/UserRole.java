package com.eureka.auth.security;

public enum UserRole {
	USER, ADMIN;
}
